import React from 'react';
import { AnalyticsData, PainterStyle, Language, ThemeMode } from '../types';
import { TRANSLATIONS } from '../constants';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface AnalyticsProps {
  data: AnalyticsData;
  currentStyle: PainterStyle;
  currentLang: Language;
  currentTheme: ThemeMode;
}

const Analytics: React.FC<AnalyticsProps> = ({ data, currentStyle, currentLang, currentTheme }) => {
  const t = TRANSLATIONS[currentLang];

  const cardStyle = {
    backgroundColor: currentTheme === 'dark' ? currentStyle.palette.panel : '#fff',
    borderColor: currentStyle.palette.secondary,
    color: currentStyle.palette.text
  };

  // Prepare data for charts
  const agentData = Object.entries(data.agentUsage).map(([name, count]) => ({ name, count }));

  return (
    <div className="p-8 h-full overflow-y-auto">
      <h2 className="text-3xl font-serif font-bold mb-8" style={{ color: currentStyle.palette.primary }}>{t.analytics}</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="p-6 rounded-xl border shadow-sm" style={cardStyle}>
          <h3 className="text-sm uppercase opacity-70 mb-2">{t.totalMessages}</h3>
          <p className="text-4xl font-bold" style={{ color: currentStyle.palette.primary }}>{data.messagesCount}</p>
        </div>
        <div className="p-6 rounded-xl border shadow-sm" style={cardStyle}>
          <h3 className="text-sm uppercase opacity-70 mb-2">{t.tokens}</h3>
          <p className="text-4xl font-bold" style={{ color: currentStyle.palette.accent }}>{data.tokensUsed}</p>
        </div>
        <div className="p-6 rounded-xl border shadow-sm" style={cardStyle}>
          <h3 className="text-sm uppercase opacity-70 mb-2">{t.invocations}</h3>
          <p className="text-4xl font-bold" style={{ color: currentStyle.palette.secondary }}>
            {Object.values(data.agentUsage).reduce((a: number, b: number) => a + b, 0)}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-96">
        <div className="p-6 rounded-xl border shadow-sm flex flex-col" style={cardStyle}>
           <h3 className="text-lg font-bold mb-4">Agent Usage Distribution</h3>
           <div className="flex-1">
             <ResponsiveContainer width="100%" height="100%">
               <BarChart data={agentData}>
                 <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.1} />
                 <XAxis dataKey="name" tick={{ fontSize: 10, fill: currentStyle.palette.text }} />
                 <YAxis tick={{ fontSize: 10, fill: currentStyle.palette.text }} />
                 <Tooltip 
                   contentStyle={{ backgroundColor: currentStyle.palette.background, borderColor: currentStyle.palette.primary }}
                 />
                 <Bar dataKey="count" fill={currentStyle.palette.primary} radius={[4, 4, 0, 0]} />
               </BarChart>
             </ResponsiveContainer>
           </div>
        </div>

        <div className="p-6 rounded-xl border shadow-sm flex flex-col" style={cardStyle}>
           <h3 className="text-lg font-bold mb-4">Activity Over Time</h3>
           <div className="flex-1">
             <ResponsiveContainer width="100%" height="100%">
               <LineChart data={data.history}>
                 <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.1} />
                 <XAxis dataKey="date" tick={{ fontSize: 10, fill: currentStyle.palette.text }} />
                 <YAxis tick={{ fontSize: 10, fill: currentStyle.palette.text }} />
                 <Tooltip 
                    contentStyle={{ backgroundColor: currentStyle.palette.background, borderColor: currentStyle.palette.primary }}
                 />
                 <Line type="monotone" dataKey="count" stroke={currentStyle.palette.accent} strokeWidth={3} dot={{ fill: currentStyle.palette.primary }} />
               </LineChart>
             </ResponsiveContainer>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;