import { Agent, PainterStyle, RegulatoryChecklistItem } from './types';

export const PAINTER_STYLES: PainterStyle[] = [
  {
    id: 'van_gogh',
    name: 'Vincent van Gogh',
    description: 'Starry Night Blues & Yellows',
    fontPairing: 'Merriweather',
    palette: { primary: '#1d3354', secondary: '#d4a017', accent: '#e8bb58', background: '#0b1d38', text: '#ffffff', panel: '#2a446b' }
  },
  {
    id: 'monet',
    name: 'Claude Monet',
    description: 'Impressionist Pastels',
    fontPairing: 'Roboto',
    palette: { primary: '#6d8a96', secondary: '#b8c5d6', accent: '#e6cfd9', background: '#f0f4f8', text: '#2c3e50', panel: '#ffffff' }
  },
  {
    id: 'picasso',
    name: 'Pablo Picasso',
    description: 'Cubist Vibrancy',
    fontPairing: 'Roboto',
    palette: { primary: '#e74c3c', secondary: '#f1c40f', accent: '#3498db', background: '#ecf0f1', text: '#2c3e50', panel: '#ffffff' }
  },
  {
    id: 'dali',
    name: 'Salvador Dalí',
    description: 'Surrealist Dream',
    fontPairing: 'Merriweather',
    palette: { primary: '#8e44ad', secondary: '#d35400', accent: '#2ecc71', background: '#2c3e50', text: '#ecf0f1', panel: '#34495e' }
  },
  {
    id: 'rembrandt',
    name: 'Rembrandt',
    description: 'Chiaroscuro Dark & Gold',
    fontPairing: 'Merriweather',
    palette: { primary: '#3e2723', secondary: '#ffb300', accent: '#d7ccc8', background: '#1a120e', text: '#ffecb3', panel: '#4e342e' }
  },
  {
    id: 'kahlo',
    name: 'Frida Kahlo',
    description: 'Mexican Folk Vibrant',
    fontPairing: 'Roboto',
    palette: { primary: '#c0392b', secondary: '#27ae60', accent: '#f39c12', background: '#fff3e0', text: '#212121', panel: '#ffffff' }
  },
  {
    id: 'hokusai',
    name: 'Hokusai',
    description: 'Great Wave Indigo',
    fontPairing: 'Roboto',
    palette: { primary: '#2980b9', secondary: '#ecf0f1', accent: '#e74c3c', background: '#eaf2f8', text: '#2c3e50', panel: '#ffffff' }
  },
  {
    id: 'klimt',
    name: 'Gustav Klimt',
    description: 'Golden Art Nouveau',
    fontPairing: 'Merriweather',
    palette: { primary: '#ffd700', secondary: '#000000', accent: '#daa520', background: '#1c1c1c', text: '#ffd700', panel: '#333333' }
  },
  {
    id: 'warhol',
    name: 'Andy Warhol',
    description: 'Pop Art Neon',
    fontPairing: 'Roboto',
    palette: { primary: '#ff00ff', secondary: '#ffff00', accent: '#00ffff', background: '#111111', text: '#ffffff', panel: '#222222' }
  },
  {
    id: 'okeeffe',
    name: 'Georgia O\'Keeffe',
    description: 'Modernist Floral',
    fontPairing: 'Merriweather',
    palette: { primary: '#e91e63', secondary: '#fce4ec', accent: '#880e4f', background: '#fff0f5', text: '#4a148c', panel: '#ffffff' }
  },
  {
    id: 'matisse',
    name: 'Henri Matisse',
    description: 'Fauvism Cutouts',
    fontPairing: 'Roboto',
    palette: { primary: '#3f51b5', secondary: '#ff5722', accent: '#4caf50', background: '#fafafa', text: '#212121', panel: '#ffffff' }
  },
  {
    id: 'pollock',
    name: 'Jackson Pollock',
    description: 'Abstract Expressionism',
    fontPairing: 'Roboto',
    palette: { primary: '#607d8b', secondary: '#ff9800', accent: '#9e9e9e', background: '#eceff1', text: '#263238', panel: '#ffffff' }
  },
  {
    id: 'munk',
    name: 'Edvard Munch',
    description: 'Expressionist Scream',
    fontPairing: 'Merriweather',
    palette: { primary: '#e67e22', secondary: '#34495e', accent: '#c0392b', background: '#2c3e50', text: '#ecf0f1', panel: '#34495e' }
  },
  {
    id: 'hopper',
    name: 'Edward Hopper',
    description: 'Realist Melancholy',
    fontPairing: 'Merriweather',
    palette: { primary: '#006064', secondary: '#fff9c4', accent: '#b71c1c', background: '#cfd8dc', text: '#263238', panel: '#ffffff' }
  },
  {
    id: 'basquiat',
    name: 'Jean-Michel Basquiat',
    description: 'Neo-expressionist Graffiti',
    fontPairing: 'Roboto',
    palette: { primary: '#000000', secondary: '#f44336', accent: '#ffeb3b', background: '#f5f5f5', text: '#000000', panel: '#ffffff' }
  },
  {
    id: 'renoir',
    name: 'Pierre-Auguste Renoir',
    description: 'Soft Impressionism',
    fontPairing: 'Merriweather',
    palette: { primary: '#f06292', secondary: '#e1bee7', accent: '#ba68c8', background: '#f3e5f5', text: '#4a148c', panel: '#ffffff' }
  },
  {
    id: 'cezanne',
    name: 'Paul Cézanne',
    description: 'Post-Impressionist Earth',
    fontPairing: 'Merriweather',
    palette: { primary: '#558b2f', secondary: '#ff8f00', accent: '#795548', background: '#fff8e1', text: '#33691e', panel: '#ffffff' }
  },
  {
    id: 'kandinsky',
    name: 'Wassily Kandinsky',
    description: 'Geometric Abstract',
    fontPairing: 'Roboto',
    palette: { primary: '#1565c0', secondary: '#ffeb3b', accent: '#d32f2f', background: '#e3f2fd', text: '#0d47a1', panel: '#ffffff' }
  },
  {
    id: 'rothko',
    name: 'Mark Rothko',
    description: 'Color Field',
    fontPairing: 'Roboto',
    palette: { primary: '#b71c1c', secondary: '#ff6f00', accent: '#3e2723', background: '#212121', text: '#ffebee', panel: '#424242' }
  },
  {
    id: 'vermeer',
    name: 'Johannes Vermeer',
    description: 'Dutch Golden Light',
    fontPairing: 'Merriweather',
    palette: { primary: '#1976d2', secondary: '#ffecb3', accent: '#ffca28', background: '#263238', text: '#eceff1', panel: '#37474f' }
  }
];

export const AGENTS: Agent[] = [
  { id: 'customer_service', name: 'Customer Service Bot', role: 'Support', category: 'Support', description: 'Handles queries, troubleshoots.' },
  { id: 'ticket_manager', name: 'Ticket Manager', role: 'Automation', category: 'Automation', description: 'Routes and classifies tickets.' },
  { id: 'sentiment_analyst', name: 'Sentiment Analyst', role: 'Analysis', category: 'Analysis', description: 'Monitors customer sentiment.' },
  { id: 'product_expert', name: 'Product Knowledge Expert', role: 'Knowledge Base', category: 'Knowledge Base', description: 'Detailed product info.' },
  { id: 'hr_assistant', name: 'HR Assistant', role: 'HR', category: 'HR', description: 'Policies, benefits, leave.' },
  { id: 'financial_analyst', name: 'Financial Analyst', role: 'Finance', category: 'Finance', description: 'Financial reports and insights.' },
  { id: 'code_generator', name: 'Code Generator', role: 'Development', category: 'Development', description: 'Generates code snippets.' },
  { id: 'content_creator', name: 'Content Creator', role: 'Marketing', category: 'Marketing', description: 'Marketing and creative content.' },
  { id: 'compliance_officer', name: 'Compliance Officer', role: 'Legal', category: 'Legal', description: 'Ensures regulatory adherence.' },
  { id: 'qa_tester', name: 'QA Tester', role: 'Development', category: 'Development', description: 'Drafts test cases.' },
  { id: 'project_manager', name: 'Project Manager', role: 'Management', category: 'Management', description: 'Tracks milestones and resources.' },
  { id: 'data_scientist', name: 'Data Scientist', role: 'Analysis', category: 'Analysis', description: 'Statistical modeling.' },
  { id: 'ui_ux_designer', name: 'UI/UX Designer', role: 'Design', category: 'Design', description: 'Interface recommendations.' },
  { id: 'security_specialist', name: 'Security Specialist', role: 'IT', category: 'IT', description: 'Vulnerability assessment.' },
  { id: 'translator', name: 'Translator', role: 'Localization', category: 'Localization', description: 'Multi-language support.' },
  { id: 'legal_advisor', name: 'Legal Advisor', role: 'Legal', category: 'Legal', description: 'Contract review.' },
  { id: 'market_researcher', name: 'Market Researcher', role: 'Marketing', category: 'Marketing', description: 'Competitor analysis.' },
  { id: 'sales_rep', name: 'Sales Representative', role: 'Sales', category: 'Sales', description: 'Lead qualification.' },
  { id: 'sys_admin', name: 'System Admin', role: 'IT', category: 'IT', description: 'System health monitoring.' },
  { id: 'devops_engineer', name: 'DevOps Engineer', role: 'Development', category: 'Development', description: 'CI/CD pipeline optimization.' },
  { id: 'social_media_manager', name: 'Social Media Manager', role: 'Marketing', category: 'Marketing', description: 'Engagement tracking.' },
  { id: 'seo_specialist', name: 'SEO Specialist', role: 'Marketing', category: 'Marketing', description: 'Keyword optimization.' },
  { id: 'copywriter', name: 'Copywriter', role: 'Marketing', category: 'Marketing', description: 'Ad copy generation.' },
  { id: 'technical_writer', name: 'Technical Writer', role: 'Documentation', category: 'Documentation', description: 'Manuals and docs.' },
  { id: 'database_admin', name: 'Database Admin', role: 'IT', category: 'IT', description: 'Query optimization.' },
  { id: 'network_engineer', name: 'Network Engineer', role: 'IT', category: 'IT', description: 'Connectivity solutions.' },
  { id: 'scrum_master', name: 'Scrum Master', role: 'Management', category: 'Management', description: 'Agile process facilitation.' },
  { id: 'product_owner', name: 'Product Owner', role: 'Management', category: 'Management', description: 'Backlog prioritization.' },
  { id: 'business_analyst', name: 'Business Analyst', role: 'Analysis', category: 'Analysis', description: 'Requirement gathering.' },
  { id: 'training_coordinator', name: 'Training Coordinator', role: 'HR', category: 'HR', description: 'Employee upskilling.' },
  { id: 'onboarding_specialist', name: 'Onboarding Specialist', role: 'HR', category: 'HR', description: 'New hire integration.' },
];

export const REGULATORY_CHECKLIST: RegulatoryChecklistItem[] = [
  { id: '1', text: 'Device Description included', checked: false, category: 'Administrative' },
  { id: '2', text: 'Indications for Use Statement', checked: false, category: 'Administrative' },
  { id: '3', text: 'Substantial Equivalence Discussion', checked: false, category: 'Technical' },
  { id: '4', text: 'Biocompatibility Testing', checked: false, category: 'Safety' },
  { id: '5', text: 'Software Verification & Validation', checked: false, category: 'Software' },
  { id: '6', text: 'Sterilization Validation', checked: false, category: 'Safety' },
  { id: '7', text: 'Labeling & Instructions for Use', checked: false, category: 'Administrative' },
  { id: '8', text: 'Risk Management File (ISO 14971)', checked: false, category: 'Risk' },
];

export const TRANSLATIONS = {
  EN: {
    appTitle: 'Multi-Agent Workspace',
    generalChat: 'General Chat',
    domainAnalysis: '510(k) Analysis',
    selectAgent: 'Select Agent',
    agents: 'Agents',
    chatHistory: 'Chat History',
    analytics: 'Analytics',
    jackpot: 'Style Jackpot',
    spin: 'SPIN!',
    theme: 'Theme',
    language: 'Language',
    upload: 'Upload Documents',
    checklist: 'Regulatory Checklist',
    report: 'Compliance Report',
    typeMessage: 'Type your message...',
    send: 'Send',
    tokens: 'Tokens Used',
    invocations: 'Agent Invocations',
    totalMessages: 'Total Messages',
    analyze: 'Analyze Submission',
    uploadDesc: 'Upload PDF, DOCX, or TXT for 510(k) review.',
    generating: 'Generating...',
    settings: 'Settings',
    hideSidebar: 'Hide Sidebar',
    showSidebar: 'Show Sidebar',
    documents: 'Documents',
    addDocument: 'Add Document',
    pasteText: 'Paste Text',
    uploadFile: 'Upload File',
    preview: 'Preview',
    closePreview: 'Close Preview',
    pdfView: 'PDF View',
    docTitle: 'Document Title',
    docContent: 'Document Content',
    add: 'Add',
  },
  TC: {
    appTitle: '多智能體工作區',
    generalChat: '一般聊天',
    domainAnalysis: '510(k) 分析',
    selectAgent: '選擇智能體',
    agents: '智能體',
    chatHistory: '聊天記錄',
    analytics: '分析',
    jackpot: '風格大獎',
    spin: '旋轉!',
    theme: '主題',
    language: '語言',
    upload: '上傳文件',
    checklist: '法規檢查表',
    report: '合規報告',
    typeMessage: '輸入訊息...',
    send: '發送',
    tokens: '使用代幣',
    invocations: '智能體調用',
    totalMessages: '總訊息數',
    analyze: '分析提交',
    uploadDesc: '上傳 PDF, DOCX 或 TXT 進行 510(k) 審查。',
    generating: '生成中...',
    settings: '設置',
    hideSidebar: '隱藏側欄',
    showSidebar: '顯示側欄',
    documents: '文件',
    addDocument: '添加文件',
    pasteText: '貼上文本',
    uploadFile: '上傳檔案',
    preview: '預覽',
    closePreview: '關閉預覽',
    pdfView: 'PDF 檢視',
    docTitle: '文件標題',
    docContent: '文件內容',
    add: '添加',
  }
};
