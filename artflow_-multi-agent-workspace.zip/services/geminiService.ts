import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const apiKey = process.env.API_KEY || '';

// Initialize only if key is present to avoid immediate crash on load if missing
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
}

export const generateResponse = async (
  prompt: string, 
  systemInstruction?: string
): Promise<string> => {
  if (!ai) {
    return "Error: API Key is missing. Please check your environment configuration.";
  }

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
      }
    });

    return response.text || "No response text generated.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return `Error connecting to AI service: ${(error as Error).message}`;
  }
};
