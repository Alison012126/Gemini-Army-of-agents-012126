import React, { useState, useEffect } from 'react';
import { PainterStyle, Language } from '../types';
import { PAINTER_STYLES, TRANSLATIONS } from '../constants';
import { X, Trophy } from 'lucide-react';

interface JackpotProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectStyle: (style: PainterStyle) => void;
  currentLang: Language;
}

const JackpotStyleSelector: React.FC<JackpotProps> = ({ isOpen, onClose, onSelectStyle, currentLang }) => {
  const [spinning, setSpinning] = useState(false);
  const [displayedStyle, setDisplayedStyle] = useState<PainterStyle>(PAINTER_STYLES[0]);
  const [highlight, setHighlight] = useState(false);
  const t = TRANSLATIONS[currentLang];

  useEffect(() => {
    if (!isOpen) {
      setSpinning(false);
      setHighlight(false);
    }
  }, [isOpen]);

  const spin = () => {
    setSpinning(true);
    setHighlight(false);
    let counter = 0;
    const maxSpins = 30; // Number of flickers before stopping
    const speed = 100;

    const interval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * PAINTER_STYLES.length);
      setDisplayedStyle(PAINTER_STYLES[randomIndex]);
      counter++;

      if (counter >= maxSpins) {
        clearInterval(interval);
        setSpinning(false);
        setHighlight(true);
        // Add a slight delay before actually applying to app to let user see result
        setTimeout(() => {
           onSelectStyle(PAINTER_STYLES[randomIndex]);
        }, 1000);
      }
    }, speed);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-80 backdrop-blur-sm">
      <div className="relative w-full max-w-md bg-white rounded-3xl overflow-hidden shadow-2xl transform transition-all scale-100">
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black bg-opacity-20 hover:bg-opacity-40 text-white"
        >
          <X size={20} />
        </button>

        <div className="p-8 flex flex-col items-center text-center space-y-6" style={{ background: `linear-gradient(135deg, ${displayedStyle.palette.primary}, ${displayedStyle.palette.background})` }}>
          
          <h2 className="text-3xl font-bold text-white drop-shadow-md tracking-wider uppercase mb-4">
            {t.jackpot}
          </h2>

          <div className={`w-48 h-48 rounded-full border-8 shadow-inner flex items-center justify-center bg-white transition-all duration-300 ${highlight ? 'scale-110 ring-4 ring-yellow-400' : ''}`}
               style={{ borderColor: displayedStyle.palette.secondary }}
          >
             <div className="text-center p-2">
               <h3 className="text-2xl font-serif font-bold" style={{ color: displayedStyle.palette.primary }}>
                 {displayedStyle.name}
               </h3>
               <p className="text-xs mt-2 text-gray-500">{displayedStyle.description}</p>
             </div>
          </div>

          <div className="flex space-x-2 mt-4">
            {Object.values(displayedStyle.palette).slice(0, 5).map((color, idx) => (
              <div key={idx} className="w-8 h-8 rounded-full shadow-md border-2 border-white" style={{ backgroundColor: color }}></div>
            ))}
          </div>

          <button
            onClick={spin}
            disabled={spinning}
            className={`mt-8 px-10 py-4 rounded-full text-xl font-bold shadow-xl transform transition-all active:scale-95 flex items-center ${spinning ? 'opacity-80 cursor-not-allowed' : 'hover:-translate-y-1 hover:shadow-2xl'}`}
            style={{ 
              backgroundColor: spinning ? '#555' : '#FFD700', 
              color: spinning ? '#ccc' : '#000'
            }}
          >
            {spinning ? '...' : (
              <>
                <Trophy className="mr-2" />
                {t.spin}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default JackpotStyleSelector;
