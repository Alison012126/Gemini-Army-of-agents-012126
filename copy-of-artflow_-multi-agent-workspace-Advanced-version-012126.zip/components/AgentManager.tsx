import React, { useState } from 'react';
import { Agent, PainterStyle, Language, ThemeMode } from '../types';
import { TRANSLATIONS } from '../constants';
import { Save, Download, Upload, Cpu, Edit3, Check, RefreshCw } from 'lucide-react';
import { generateResponse } from '../services/geminiService';
import * as yaml from 'js-yaml';

interface AgentManagerProps {
  agents: Agent[];
  setAgents: (agents: Agent[]) => void;
  currentStyle: PainterStyle;
  currentLang: Language;
  currentTheme: ThemeMode;
  onUpdateAgent: (agent: Agent) => void;
}

const AgentManager: React.FC<AgentManagerProps> = ({ 
  agents, setAgents, currentStyle, currentLang, currentTheme, onUpdateAgent 
}) => {
  const t = TRANSLATIONS[currentLang];
  const [selectedId, setSelectedId] = useState<string>(agents[0]?.id || '');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState('');

  // Editing State
  const selectedAgent = agents.find(a => a.id === selectedId);
  const [editModel, setEditModel] = useState(selectedAgent?.model || 'gemini-3-flash-preview');
  const [editPrompt, setEditPrompt] = useState(selectedAgent?.systemInstruction || selectedAgent?.description || '');

  // Update local edit state when selection changes
  React.useEffect(() => {
    if (selectedAgent) {
      setEditModel(selectedAgent.model || 'gemini-3-flash-preview');
      setEditPrompt(selectedAgent.systemInstruction || selectedAgent.description);
    }
  }, [selectedAgent]);

  const handleSave = () => {
    if (selectedAgent) {
      const updatedAgent = {
        ...selectedAgent,
        model: editModel,
        systemInstruction: editPrompt
      };
      onUpdateAgent(updatedAgent);
    }
  };

  const handleDownloadYaml = () => {
    const yamlStr = yaml.dump(agents);
    const blob = new Blob([yamlStr], { type: 'text/yaml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'agents.yaml';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleUploadYaml = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const content = ev.target?.result as string;
        try {
          // Attempt simple parse first
          const parsed = yaml.load(content) as any;
          
          if (Array.isArray(parsed) && parsed.every(a => a.id && a.name)) {
             setAgents(parsed as Agent[]);
          } else {
             // Structure is wrong, use LLM to standardize
             await standardizeAgents(content);
          }
        } catch (error) {
           // Parse error, use LLM to fix/standardize
           await standardizeAgents(content);
        }
      };
      reader.readAsText(file);
    }
  };

  const standardizeAgents = async (rawContent: string) => {
    setIsProcessing(true);
    setProcessingStatus(t.standardizing);
    
    const prompt = `You are a Data Standardization Agent.
    Transform the following raw text/data into a strictly standard YAML format for a list of AI Agents.
    
    Target Schema (YAML List of Objects):
    - id: string (unique, snake_case)
    - name: string
    - role: string
    - category: string
    - description: string
    - model: string (default to 'gemini-3-flash-preview' if unknown)
    - systemInstruction: string (optional)

    Raw Input:
    ${rawContent.substring(0, 15000)}

    Output ONLY the valid YAML. No markdown fences.`;

    try {
      const result = await generateResponse(prompt, undefined, 'gemini-3-flash-preview');
      // Clean result if it has markdown fences
      const cleanYaml = result.replace(/```yaml/g, '').replace(/```/g, '').trim();
      const standardizedAgents = yaml.load(cleanYaml) as Agent[];
      
      if (Array.isArray(standardizedAgents)) {
        setAgents(standardizedAgents);
      } else {
        alert("Failed to standardize agents.");
      }
    } catch (e) {
      console.error(e);
      alert("Error processing YAML.");
    } finally {
      setIsProcessing(false);
      setProcessingStatus('');
    }
  };

  const cardStyle = {
    backgroundColor: currentTheme === 'dark' ? currentStyle.palette.panel : '#fff',
    borderColor: currentStyle.palette.secondary,
    color: currentStyle.palette.text
  };

  return (
    <div className="flex h-full p-6 space-x-6 overflow-hidden">
      {/* Left Column: List */}
      <div className="w-1/3 flex flex-col space-y-4 rounded-xl border p-4 shadow-sm" style={cardStyle}>
        <div className="flex justify-between items-center mb-2">
           <h3 className="font-bold text-lg font-serif">{t.agents}</h3>
           <div className="flex space-x-2">
             <button onClick={handleDownloadYaml} className="p-2 rounded hover:bg-black hover:bg-opacity-10" title={t.exportAgents}>
               <Download size={18} />
             </button>
             <div className="relative">
               <input type="file" onChange={handleUploadYaml} className="absolute inset-0 opacity-0 cursor-pointer" accept=".yaml,.yml,.txt" />
               <button className="p-2 rounded hover:bg-black hover:bg-opacity-10" title={t.importAgents}>
                 <Upload size={18} />
               </button>
             </div>
           </div>
        </div>

        {isProcessing && (
           <div className="p-4 bg-yellow-100 text-yellow-800 rounded flex items-center text-xs">
             <RefreshCw className="animate-spin mr-2" size={12} />
             {processingStatus}
           </div>
        )}

        <div className="flex-1 overflow-y-auto space-y-2 pr-2">
          {agents.map(agent => (
            <button
              key={agent.id}
              onClick={() => setSelectedId(agent.id)}
              className={`w-full text-left p-3 rounded-lg border transition-all flex items-center justify-between ${selectedId === agent.id ? 'shadow-md ring-1' : 'hover:opacity-80'}`}
              style={{
                backgroundColor: selectedId === agent.id ? currentStyle.palette.primary : 'transparent',
                color: selectedId === agent.id ? '#fff' : currentStyle.palette.text,
                borderColor: currentStyle.palette.secondary
              }}
            >
              <div>
                <div className="font-bold text-sm">{agent.name}</div>
                <div className="text-xs opacity-70">{agent.role}</div>
              </div>
              {selectedId === agent.id && <Edit3 size={14} />}
            </button>
          ))}
        </div>
      </div>

      {/* Right Column: Editor */}
      <div className="flex-1 rounded-xl border p-6 shadow-sm flex flex-col overflow-y-auto" style={cardStyle}>
        {selectedAgent ? (
          <>
            <div className="flex items-center space-x-4 mb-6 pb-4 border-b" style={{ borderColor: currentStyle.palette.secondary }}>
              <div className="p-3 rounded-full shadow-lg" style={{ backgroundColor: currentStyle.palette.accent, color: '#fff' }}>
                <Cpu size={32} />
              </div>
              <div>
                <h2 className="text-2xl font-bold font-serif">{selectedAgent.name}</h2>
                <p className="opacity-70">{selectedAgent.role} • {selectedAgent.category}</p>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold uppercase mb-2 opacity-70">{t.model}</label>
                <div className="relative">
                  <select
                    value={editModel}
                    onChange={(e) => setEditModel(e.target.value)}
                    className="w-full p-3 rounded border appearance-none focus:outline-none focus:ring-2"
                    style={{ 
                      backgroundColor: currentTheme === 'dark' ? 'rgba(0,0,0,0.2)' : '#f8fafc',
                      borderColor: currentStyle.palette.primary,
                      color: currentStyle.palette.text
                    }}
                  >
                    <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
                    <option value="gemini-3-flash-preview">Gemini 3.0 Flash Preview</option>
                  </select>
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none opacity-50">
                    <Cpu size={16} />
                  </div>
                </div>
              </div>

              <div className="flex-1">
                <label className="block text-sm font-bold uppercase mb-2 opacity-70">{t.systemPrompt}</label>
                <textarea
                  value={editPrompt}
                  onChange={(e) => setEditPrompt(e.target.value)}
                  className="w-full h-64 p-4 rounded border focus:outline-none focus:ring-2 font-mono text-sm leading-relaxed"
                  style={{ 
                    backgroundColor: currentTheme === 'dark' ? 'rgba(0,0,0,0.2)' : '#f8fafc',
                    borderColor: currentStyle.palette.primary,
                    color: currentStyle.palette.text
                  }}
                  placeholder="Enter system instructions..."
                />
              </div>

              <div className="flex justify-end pt-4">
                <button
                  onClick={handleSave}
                  className="px-8 py-3 rounded-lg font-bold shadow-lg flex items-center transition-transform hover:scale-105 active:scale-95"
                  style={{ backgroundColor: currentStyle.palette.primary, color: '#fff' }}
                >
                  <Save size={18} className="mr-2" />
                  {t.save}
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full opacity-50">
            Select an agent to edit
          </div>
        )}
      </div>
    </div>
  );
};

export default AgentManager;
