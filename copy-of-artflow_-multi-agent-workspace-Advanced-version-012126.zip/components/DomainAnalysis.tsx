import React, { useState } from 'react';
import { PainterStyle, Language, ThemeMode, RegulatoryChecklistItem, AppStatus } from '../types';
import { REGULATORY_CHECKLIST, TRANSLATIONS } from '../constants';
import { Upload, CheckCircle, FileText, AlertCircle, PieChart, Trash2 } from 'lucide-react';
import { generateResponse } from '../services/geminiService';

interface DomainAnalysisProps {
  currentLang: Language;
  currentStyle: PainterStyle;
  currentTheme: ThemeMode;
  incrementUsage: () => void;
  setAppStatus: (status: AppStatus) => void;
}

interface UploadedFile {
  name: string;
  content: string;
}

const DomainAnalysis: React.FC<DomainAnalysisProps> = ({
  currentLang, currentStyle, currentTheme, incrementUsage, setAppStatus
}) => {
  const t = TRANSLATIONS[currentLang];
  const [subTab, setSubTab] = useState<'upload' | 'checklist' | 'report'>('upload');
  const [checklist, setChecklist] = useState(REGULATORY_CHECKLIST);
  const [analyzing, setAnalyzing] = useState(false);
  const [reportText, setReportText] = useState<string | null>(null);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);

  const toggleCheck = (id: string) => {
    setChecklist(prev => prev.map(item => item.id === id ? { ...item, checked: !item.checked } : item));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      Array.from(e.target.files).forEach((file: File) => {
        const reader = new FileReader();
        reader.onload = (ev) => {
          const content = ev.target?.result as string;
          setUploadedFiles(prev => [...prev, { name: file.name, content }]);
        };
        reader.readAsText(file);
      });
    }
  };

  const removeFile = (name: string) => {
    setUploadedFiles(prev => prev.filter(f => f.name !== name));
  };

  const handleAnalysis = async () => {
    setAnalyzing(true);
    setSubTab('report');
    setAppStatus('thinking');
    incrementUsage();
    
    const checkedItems = checklist.filter(i => i.checked).map(i => i.text).join(', ');
    
    let fileContext = "";
    if (uploadedFiles.length > 0) {
      fileContext = "\n\nAttached Regulatory Documents for Review:\n";
      uploadedFiles.forEach(f => {
        fileContext += `--- Document: ${f.name} ---\n${f.content.substring(0, 10000)}...\n(truncated)\n----------------\n`;
      });
    }

    const prompt = `Generate a 510(k) Pre-market Notification Compliance Report.
    
    Status of Regulatory Checklist items:
    Verified Items: ${checkedItems || "None"}
    
    ${fileContext}
    
    Task:
    1. Analyze the provided documents (if any) against FDA Class II medical device requirements.
    2. Identify gaps based on the unchecked items in the checklist.
    3. Generate a professional status report.
    4. Provide specific recommendations for missing sections.
    
    Format output in Markdown. Language: ${currentLang}`;

    try {
        const report = await generateResponse(prompt);
        setReportText(report);
        setAppStatus('connected');
    } catch (e) {
        setReportText("Error generating report.");
        setAppStatus('error');
    } finally {
        setAnalyzing(false);
    }
  };

  const activeTabStyle = {
    borderBottom: `3px solid ${currentStyle.palette.primary}`,
    color: currentStyle.palette.primary,
    fontWeight: 'bold',
  };

  return (
    <div className="h-full flex flex-col p-6 overflow-y-auto">
      <h2 className="text-3xl font-serif font-bold mb-6" style={{ color: currentStyle.palette.primary }}>
        {t.domainAnalysis}
      </h2>

      {/* Sub Tabs */}
      <div className="flex space-x-6 mb-8 border-b" style={{ borderColor: currentStyle.palette.secondary }}>
        <button 
          onClick={() => setSubTab('upload')}
          className="pb-3 px-2 transition-colors"
          style={subTab === 'upload' ? activeTabStyle : { color: currentStyle.palette.text }}
        >
          {t.upload}
        </button>
        <button 
          onClick={() => setSubTab('checklist')}
          className="pb-3 px-2 transition-colors"
          style={subTab === 'checklist' ? activeTabStyle : { color: currentStyle.palette.text }}
        >
          {t.checklist}
        </button>
        <button 
          onClick={() => setSubTab('report')}
          className="pb-3 px-2 transition-colors"
          style={subTab === 'report' ? activeTabStyle : { color: currentStyle.palette.text }}
        >
          {t.report}
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 bg-white bg-opacity-50 rounded-xl p-8 shadow-sm border" style={{ 
        backgroundColor: currentTheme === 'dark' ? currentStyle.palette.panel : '#fff',
        borderColor: currentStyle.palette.secondary
      }}>
        
        {subTab === 'upload' && (
          <div className="h-full flex flex-col">
            <div className="flex-1 flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-10 transition-all hover:bg-opacity-50 mb-4" style={{ borderColor: currentStyle.palette.accent, backgroundColor: currentStyle.palette.secondary + '10' }}>
              <div className="bg-opacity-20 p-6 rounded-full mb-4" style={{ backgroundColor: currentStyle.palette.primary }}>
                <Upload size={48} style={{ color: currentStyle.palette.primary }} />
              </div>
              <h3 className="text-xl font-bold mb-2">{t.upload}</h3>
              <p className="opacity-70 mb-6 text-center max-w-md">{t.uploadDesc}</p>
              <input 
                type="file" 
                className="hidden" 
                id="file-upload" 
                multiple 
                onChange={handleFileUpload}
                accept=".txt,.md,.json,.csv" 
              />
              <label htmlFor="file-upload" className="cursor-pointer px-6 py-3 rounded-lg font-bold shadow-lg transition-transform hover:scale-105" style={{ backgroundColor: currentStyle.palette.primary, color: '#fff' }}>
                Select Files
              </label>
            </div>
            
            {/* File List */}
            {uploadedFiles.length > 0 && (
              <div className="mt-4">
                <h4 className="font-bold mb-2 opacity-80">Uploaded Documents:</h4>
                <div className="space-y-2">
                  {uploadedFiles.map((file, idx) => (
                    <div key={idx} className="flex justify-between items-center p-3 rounded bg-opacity-10 border" style={{ backgroundColor: currentStyle.palette.secondary, borderColor: currentStyle.palette.secondary }}>
                      <div className="flex items-center">
                        <FileText size={16} className="mr-2" />
                        <span className="text-sm font-medium">{file.name}</span>
                      </div>
                      <button onClick={() => removeFile(file.name)} className="opacity-60 hover:opacity-100 hover:text-red-500">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {subTab === 'checklist' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center mb-4">
               <h3 className="text-xl font-bold">FDA 510(k) Requirements</h3>
               <button 
                 onClick={handleAnalysis}
                 className="px-4 py-2 rounded shadow-md font-bold hover:opacity-90"
                 style={{ backgroundColor: currentStyle.palette.accent, color: '#fff' }}
               >
                 {t.analyze}
               </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {checklist.map((item) => (
                <div 
                  key={item.id} 
                  onClick={() => toggleCheck(item.id)}
                  className="flex items-center p-4 rounded-lg border cursor-pointer transition-all hover:shadow-md"
                  style={{ 
                    backgroundColor: item.checked ? currentStyle.palette.secondary + '30' : 'transparent',
                    borderColor: item.checked ? currentStyle.palette.primary : currentStyle.palette.secondary 
                  }}
                >
                  <div className={`w-6 h-6 rounded border mr-3 flex items-center justify-center transition-colors`}
                    style={{ 
                      backgroundColor: item.checked ? currentStyle.palette.primary : 'transparent',
                      borderColor: currentStyle.palette.primary
                    }}
                  >
                    {item.checked && <CheckCircle size={16} color="#fff" />}
                  </div>
                  <div>
                    <span className="font-medium block">{item.text}</span>
                    <span className="text-xs opacity-60 uppercase tracking-wide">{item.category}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {subTab === 'report' && (
          <div className="h-full flex flex-col">
            {analyzing ? (
              <div className="flex flex-col items-center justify-center h-full">
                <PieChart className="animate-spin-slow mb-4" size={64} style={{ color: currentStyle.palette.primary }} />
                <p className="text-lg font-serif animate-pulse">{t.generating}</p>
              </div>
            ) : (
              <div className="prose max-w-none overflow-y-auto pr-4">
                <div className="flex items-center mb-6 p-4 rounded-lg" style={{ backgroundColor: currentStyle.palette.secondary + '20' }}>
                   <CheckCircle className="mr-3" style={{ color: currentStyle.palette.primary }} />
                   <h3 className="text-lg font-bold m-0">Compliance Analysis Complete</h3>
                </div>
                {reportText ? (
                  <div style={{ whiteSpace: 'pre-wrap' }}>{reportText}</div>
                ) : (
                  <p className="opacity-50 italic">No report generated. Go to checklist and click Analyze.</p>
                )}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};

export default DomainAnalysis;
