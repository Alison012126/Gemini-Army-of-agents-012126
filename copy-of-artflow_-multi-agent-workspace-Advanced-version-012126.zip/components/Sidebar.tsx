import React, { useState } from 'react';
import { Agent, Language, ThemeMode, PainterStyle, AppStatus } from '../types';
import { TRANSLATIONS } from '../constants';
import { LayoutDashboard, MessageSquare, FileText, Settings, History, BarChart2, Globe, Moon, Sun, Palette, ChevronLeft, Zap, Activity, AlertTriangle, Users } from 'lucide-react';

interface SidebarProps {
  currentLang: Language;
  setLang: (l: Language) => void;
  currentTheme: ThemeMode;
  setTheme: (t: ThemeMode) => void;
  activeTab: string;
  setActiveTab: (t: string) => void;
  selectedAgent: Agent;
  onSelectAgent: (a: Agent) => void;
  agents: Agent[];
  currentStyle: PainterStyle;
  onOpenJackpot: () => void;
  onClose: () => void;
  appStatus: AppStatus;
}

const Sidebar: React.FC<SidebarProps> = ({
  currentLang, setLang,
  currentTheme, setTheme,
  activeTab, setActiveTab,
  selectedAgent, onSelectAgent,
  agents,
  currentStyle,
  onOpenJackpot,
  onClose,
  appStatus
}) => {
  const t = TRANSLATIONS[currentLang];
  const [agentSearch, setAgentSearch] = useState('');

  // Styles derived from the current Painter Style
  const sidebarStyle = {
    backgroundColor: currentTheme === 'dark' ? currentStyle.palette.panel : currentStyle.palette.background,
    color: currentStyle.palette.text,
    borderColor: currentStyle.palette.primary,
  };

  const activeLinkStyle = {
    backgroundColor: currentStyle.palette.primary,
    color: '#ffffff', // Always white for contrast on active
  };

  const filteredAgents = agents.filter(a => a.name.toLowerCase().includes(agentSearch.toLowerCase()));

  // Status Indicator Logic
  let statusColor = '#22c55e'; // Green
  let statusText = 'Neural Core Online';
  let statusIcon = <Zap size={16} />;
  let pulseClass = 'animate-pulse';

  if (appStatus === 'thinking') {
    statusColor = '#3b82f6'; // Blue
    statusText = 'Processing...';
    statusIcon = <Activity size={16} className="animate-spin" />;
    pulseClass = 'animate-pulse duration-75'; // Fast pulse
  } else if (appStatus === 'error') {
    statusColor = '#ef4444'; // Red
    statusText = 'Connection Error';
    statusIcon = <AlertTriangle size={16} />;
    pulseClass = '';
  }

  return (
    <div className="h-full flex flex-col border-r-2 shadow-xl" style={sidebarStyle}>
      {/* Header */}
      <div className="p-6 border-b border-opacity-20 flex justify-between items-start" style={{ borderColor: currentStyle.palette.primary }}>
        <div>
          <h1 className="text-2xl font-serif font-bold tracking-wide" style={{ color: currentStyle.palette.primary }}>
            {t.appTitle}
          </h1>
          <p className="text-xs opacity-70 mt-1">{currentStyle.name} Style</p>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-black hover:bg-opacity-10 rounded">
          <ChevronLeft size={20} />
        </button>
      </div>

      {/* Status Indicator (WOW UI) */}
      <div className="mx-4 mt-4 p-3 rounded-xl border flex items-center justify-between shadow-inner bg-black bg-opacity-5" 
           style={{ borderColor: statusColor }}>
        <div className="flex items-center">
           <div className={`w-3 h-3 rounded-full mr-3 ${pulseClass}`} 
                style={{ backgroundColor: statusColor, boxShadow: `0 0 12px ${statusColor}` }}></div>
           <span className="text-xs font-bold tracking-wider uppercase" style={{ color: statusColor }}>{statusText}</span>
        </div>
        <div style={{ color: statusColor }}>
          {statusIcon}
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        <button
          onClick={() => setActiveTab('chat')}
          className={`w-full flex items-center p-3 rounded-lg transition-all ${activeTab === 'chat' ? 'shadow-md' : 'hover:opacity-80'}`}
          style={activeTab === 'chat' ? activeLinkStyle : {}}
        >
          <MessageSquare className="w-5 h-5 mr-3" />
          <span className="font-medium">{t.generalChat}</span>
        </button>

        <button
          onClick={() => setActiveTab('domain')}
          className={`w-full flex items-center p-3 rounded-lg transition-all ${activeTab === 'domain' ? 'shadow-md' : 'hover:opacity-80'}`}
          style={activeTab === 'domain' ? activeLinkStyle : {}}
        >
          <FileText className="w-5 h-5 mr-3" />
          <span className="font-medium">{t.domainAnalysis}</span>
        </button>

        <button
          onClick={() => setActiveTab('agents')}
          className={`w-full flex items-center p-3 rounded-lg transition-all ${activeTab === 'agents' ? 'shadow-md' : 'hover:opacity-80'}`}
          style={activeTab === 'agents' ? activeLinkStyle : {}}
        >
          <Users className="w-5 h-5 mr-3" />
          <span className="font-medium">{t.agentStudio}</span>
        </button>

        <button onClick={() => setActiveTab('analytics')} className="w-full flex items-center p-3 rounded-lg hover:opacity-80 opacity-70" style={activeTab === 'analytics' ? activeLinkStyle : {}}>
          <BarChart2 className="w-5 h-5 mr-3" />
          <span>{t.analytics}</span>
        </button>

        <div className="mt-8 mb-2">
          <h3 className="text-xs uppercase font-bold tracking-wider opacity-60 mb-2 px-2">{t.agents}</h3>
          <input
            type="text"
            placeholder="Search agents..."
            className="w-full p-2 mb-2 text-sm rounded border bg-transparent"
            style={{ borderColor: currentStyle.palette.secondary, color: currentStyle.palette.text }}
            value={agentSearch}
            onChange={(e) => setAgentSearch(e.target.value)}
          />
          <div className="space-y-1 max-h-60 overflow-y-auto pr-1">
            {filteredAgents.map(agent => (
              <button
                key={agent.id}
                onClick={() => onSelectAgent(agent)}
                className={`w-full text-left text-sm p-2 rounded flex items-center ${selectedAgent.id === agent.id ? 'font-bold' : ''}`}
                style={{ 
                  backgroundColor: selectedAgent.id === agent.id ? currentStyle.palette.secondary : 'transparent',
                  color: selectedAgent.id === agent.id ? (currentTheme === 'dark' ? '#fff' : '#000') : 'inherit'
                }}
              >
                <span className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: currentStyle.palette.accent }}></span>
                {agent.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Footer / Settings */}
      <div className="p-4 border-t border-opacity-20 bg-black bg-opacity-5" style={{ borderColor: currentStyle.palette.primary }}>
        <div className="grid grid-cols-2 gap-2 mb-4">
          <button 
            onClick={() => setLang(currentLang === 'EN' ? 'TC' : 'EN')}
            className="flex items-center justify-center p-2 rounded hover:bg-black hover:bg-opacity-10"
          >
            <Globe className="w-4 h-4 mr-2" />
            {currentLang}
          </button>
          <button 
            onClick={() => setTheme(currentTheme === 'light' ? 'dark' : 'light')}
            className="flex items-center justify-center p-2 rounded hover:bg-black hover:bg-opacity-10"
          >
            {currentTheme === 'light' ? <Moon className="w-4 h-4 mr-2" /> : <Sun className="w-4 h-4 mr-2" />}
            {currentTheme === 'light' ? 'Dark' : 'Light'}
          </button>
        </div>
        
        <button
          onClick={onOpenJackpot}
          className="w-full p-3 rounded-lg font-bold flex items-center justify-center shadow-lg transition-transform hover:scale-105"
          style={{ 
            background: `linear-gradient(45deg, ${currentStyle.palette.primary}, ${currentStyle.palette.secondary})`, 
            color: '#fff' 
          }}
        >
          <Palette className="w-5 h-5 mr-2" />
          {t.jackpot}
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
