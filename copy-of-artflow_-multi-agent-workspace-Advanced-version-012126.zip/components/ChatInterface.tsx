import React, { useState, useRef, useEffect } from 'react';
import { Agent, ChatMessage, Language, PainterStyle, ThemeMode, AttachedDocument, AppStatus } from '../types';
import { TRANSLATIONS } from '../constants';
import { generateResponse } from '../services/geminiService';
import { Send, User, Bot, Loader2, Paperclip, FileText, X, Eye, Upload as UploadIcon, File } from 'lucide-react';

interface ChatInterfaceProps {
  currentLang: Language;
  currentStyle: PainterStyle;
  currentTheme: ThemeMode;
  selectedAgent: Agent;
  messages: ChatMessage[];
  addMessage: (msg: ChatMessage) => void;
  incrementUsage: () => void;
  setAppStatus: (status: AppStatus) => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({
  currentLang, currentStyle, currentTheme, selectedAgent, messages, addMessage, incrementUsage, setAppStatus
}) => {
  const t = TRANSLATIONS[currentLang];
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Document State
  const [documents, setDocuments] = useState<AttachedDocument[]>([]);
  const [showDocModal, setShowDocModal] = useState(false);
  const [docTab, setDocTab] = useState<'upload' | 'paste'>('upload');
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocContent, setNewDocContent] = useState('');
  const [previewDoc, setPreviewDoc] = useState<AttachedDocument | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userText = input;
    setInput('');
    setLoading(true);
    setAppStatus('thinking');

    // Add user message
    addMessage({
      id: Date.now().toString(),
      role: 'user',
      text: userText,
      timestamp: Date.now()
    });

    try {
      // Build system prompt based on agent and attached documents
      let contextInstructions = "";
      if (documents.length > 0) {
        contextInstructions = `\n\nReference the following attached documents if relevant:\n`;
        documents.forEach(doc => {
          contextInstructions += `--- Document: ${doc.title} ---\n${doc.content}\n----------------\n`;
        });
      }

      // Use the specific system instruction from the agent if edited, otherwise fallback to description
      const agentInstruction = selectedAgent.systemInstruction || selectedAgent.description;

      const systemPrompt = `You are an AI assistant acting as a ${selectedAgent.name} (${selectedAgent.role}). 
      Instructions: ${agentInstruction}. 
      Please respond in ${currentLang === 'EN' ? 'English' : 'Traditional Chinese'}.
      Keep responses concise and professional.${contextInstructions}`;

      // Use specific model from agent or default
      const modelToUse = selectedAgent.model || 'gemini-3-flash-preview';

      const responseText = await generateResponse(userText, systemPrompt, modelToUse);
      incrementUsage();

      addMessage({
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText,
        timestamp: Date.now(),
        agentId: selectedAgent.id
      });
      setAppStatus('connected');
    } catch (error) {
      addMessage({
        id: (Date.now() + 1).toString(),
        role: 'system',
        text: 'Error generating response.',
        timestamp: Date.now()
      });
      setAppStatus('error');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const content = ev.target?.result as string;
        setDocuments([...documents, {
          id: Date.now().toString(),
          title: file.name,
          content,
          type: 'text'
        }]);
        setShowDocModal(false);
      };
      reader.readAsText(file);
    }
  };

  const handlePasteDoc = () => {
    if (newDocTitle && newDocContent) {
      setDocuments([...documents, {
        id: Date.now().toString(),
        title: newDocTitle,
        content: newDocContent,
        type: 'markdown'
      }]);
      setNewDocTitle('');
      setNewDocContent('');
      setShowDocModal(false);
    }
  };

  const containerStyle = {
    backgroundColor: currentTheme === 'dark' ? 'rgba(0,0,0,0.2)' : 'rgba(255,255,255,0.5)',
    borderColor: currentStyle.palette.secondary,
  };

  return (
    <div className="flex flex-col h-full rounded-xl overflow-hidden shadow-inner border-2 transition-colors duration-500 relative" style={containerStyle}>
      {/* Header */}
      <div className="p-4 border-b flex items-center justify-between backdrop-blur-sm" style={{ backgroundColor: currentStyle.palette.primary + '20', borderColor: currentStyle.palette.secondary }}>
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full flex items-center justify-center mr-3 shadow-md" style={{ backgroundColor: currentStyle.palette.primary, color: '#fff' }}>
            <Bot size={20} />
          </div>
          <div>
            <h2 className="font-serif font-bold text-lg">{selectedAgent.name}</h2>
            <p className="text-xs opacity-70">{selectedAgent.role}</p>
          </div>
        </div>
        
        {/* Document List Indicators */}
        <div className="flex space-x-2">
           {documents.map(doc => (
             <button 
               key={doc.id}
               onClick={() => setPreviewDoc(doc)}
               className="flex items-center text-xs px-2 py-1 rounded bg-opacity-20 hover:bg-opacity-40 transition-colors"
               style={{ backgroundColor: currentStyle.palette.primary }}
             >
               <FileText size={12} className="mr-1" />
               <span className="max-w-[80px] truncate">{doc.title}</span>
             </button>
           ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div key={msg.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
              <div 
                className={`max-w-[80%] p-4 rounded-2xl shadow-md ${isUser ? 'rounded-tr-none' : 'rounded-tl-none'}`}
                style={{
                  backgroundColor: isUser ? currentStyle.palette.primary : (currentTheme === 'dark' ? currentStyle.palette.panel : '#fff'),
                  color: isUser ? '#fff' : currentStyle.palette.text,
                  border: !isUser ? `1px solid ${currentStyle.palette.secondary}` : 'none'
                }}
              >
                <div className="flex items-center mb-1 opacity-70 text-xs">
                  {isUser ? <User size={12} className="mr-1" /> : <Bot size={12} className="mr-1" />}
                  <span>{isUser ? 'You' : (msg.agentId ? selectedAgent.name : 'System')}</span>
                </div>
                <div className="whitespace-pre-wrap leading-relaxed">
                  {msg.text}
                </div>
              </div>
            </div>
          );
        })}
        {loading && (
          <div className="flex justify-start">
             <div className="bg-opacity-50 p-4 rounded-2xl rounded-tl-none flex items-center space-x-2" style={{ backgroundColor: currentStyle.palette.secondary + '40' }}>
               <Loader2 className="animate-spin" size={16} />
               <span className="text-xs">{t.generating}</span>
             </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Input */}
      <div className="p-4 bg-opacity-20 backdrop-blur-md" style={{ backgroundColor: currentStyle.palette.background }}>
        <div className="relative flex items-center space-x-2">
          <button 
             onClick={() => setShowDocModal(true)}
             className="p-3 rounded-full transition-transform hover:scale-110 active:scale-95 shadow-sm"
             style={{ backgroundColor: currentStyle.palette.secondary, color: '#fff' }}
             title={t.addDocument}
          >
            <Paperclip size={20} />
          </button>
          
          <div className="relative flex-1">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={t.typeMessage}
              className="w-full p-4 pr-12 rounded-full border-2 focus:outline-none transition-shadow shadow-sm"
              style={{ 
                borderColor: currentStyle.palette.secondary,
                backgroundColor: currentTheme === 'dark' ? 'rgba(255,255,255,0.05)' : '#fff',
                color: currentStyle.palette.text
              }}
            />
            <button
              onClick={handleSend}
              disabled={loading}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 p-2 rounded-full transition-transform hover:scale-110 active:scale-95 disabled:opacity-50"
              style={{ backgroundColor: currentStyle.palette.primary, color: '#fff' }}
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Document Modal */}
      {showDocModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90%]">
             <div className="flex justify-between items-center p-4 border-b">
               <h3 className="font-bold text-lg text-black">{t.addDocument}</h3>
               <button onClick={() => setShowDocModal(false)} className="text-gray-500 hover:text-black">
                 <X size={20} />
               </button>
             </div>
             <div className="flex border-b">
               <button 
                 onClick={() => setDocTab('upload')}
                 className={`flex-1 py-3 font-medium text-sm transition-colors ${docTab === 'upload' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:bg-gray-50'}`}
               >
                 {t.uploadFile}
               </button>
               <button 
                 onClick={() => setDocTab('paste')}
                 className={`flex-1 py-3 font-medium text-sm transition-colors ${docTab === 'paste' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:bg-gray-50'}`}
               >
                 {t.pasteText}
               </button>
             </div>
             <div className="p-6 flex-1 overflow-y-auto">
               {docTab === 'upload' ? (
                 <div className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-gray-300 rounded-lg hover:bg-gray-50 transition-colors relative">
                    <input 
                      type="file" 
                      onChange={handleFileUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      accept=".txt,.md,.json,.csv"
                    />
                    <UploadIcon className="w-12 h-12 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500 font-medium">Click or Drag to Upload (.txt, .md)</p>
                 </div>
               ) : (
                 <div className="space-y-4">
                   <div>
                     <label className="block text-xs font-bold text-gray-500 uppercase mb-1">{t.docTitle}</label>
                     <input 
                       type="text" 
                       value={newDocTitle}
                       onChange={(e) => setNewDocTitle(e.target.value)}
                       className="w-full p-2 border rounded text-black"
                       placeholder="My Document"
                     />
                   </div>
                   <div>
                     <label className="block text-xs font-bold text-gray-500 uppercase mb-1">{t.docContent}</label>
                     <textarea 
                       value={newDocContent}
                       onChange={(e) => setNewDocContent(e.target.value)}
                       className="w-full p-2 border rounded h-40 text-black font-mono text-sm"
                       placeholder="# Content goes here..."
                     />
                   </div>
                   <button 
                     onClick={handlePasteDoc}
                     className="w-full py-2 bg-blue-600 text-white rounded font-bold hover:bg-blue-700 transition-colors"
                   >
                     {t.add}
                   </button>
                 </div>
               )}
             </div>
          </div>
        </div>
      )}

      {/* PDF View Preview */}
      {previewDoc && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-90 backdrop-blur-md p-4 animate-in fade-in duration-200">
           <button 
             onClick={() => setPreviewDoc(null)} 
             className="absolute top-4 right-4 text-white hover:text-gray-300 z-50 p-2 bg-black bg-opacity-50 rounded-full"
           >
             <X size={24} />
           </button>
           
           <div className="h-full w-full max-w-4xl overflow-y-auto custom-scrollbar flex justify-center py-8">
             <div className="bg-white text-black shadow-2xl w-full max-w-[210mm] min-h-[297mm] p-[20mm] relative">
               <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-gray-200 to-gray-400"></div>
               <h1 className="text-4xl font-serif font-bold mb-8 border-b-2 border-black pb-4">{previewDoc.title}</h1>
               <div className="prose max-w-none font-serif leading-loose whitespace-pre-wrap text-justify">
                 {previewDoc.content}
               </div>
               <div className="mt-16 pt-8 border-t border-gray-300 text-center text-xs text-gray-500 font-sans">
                 Document Preview generated by ArtFlow Workspace
               </div>
             </div>
           </div>
        </div>
      )}

    </div>
  );
};

export default ChatInterface;
