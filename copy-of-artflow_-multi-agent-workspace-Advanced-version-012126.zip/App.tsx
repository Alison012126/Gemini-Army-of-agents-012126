import React, { useState, useEffect } from 'react';
import { Agent, ChatMessage, Language, PainterStyle, ThemeMode, AnalyticsData, AppStatus } from './types';
import { AGENTS, PAINTER_STYLES } from './constants';
import Sidebar from './components/Sidebar';
import ChatInterface from './components/ChatInterface';
import DomainAnalysis from './components/DomainAnalysis';
import Analytics from './components/Analytics';
import AgentManager from './components/AgentManager';
import JackpotStyleSelector from './components/JackpotStyleSelector';
import { Menu } from 'lucide-react';

const App: React.FC = () => {
  // State
  const [currentStyle, setCurrentStyle] = useState<PainterStyle>(PAINTER_STYLES[0]);
  const [themeMode, setThemeMode] = useState<ThemeMode>('light');
  const [language, setLanguage] = useState<Language>('EN');
  const [activeTab, setActiveTab] = useState<string>('chat');
  const [agents, setAgents] = useState<Agent[]>(AGENTS);
  const [selectedAgent, setSelectedAgent] = useState<Agent>(AGENTS[0]);
  const [showJackpot, setShowJackpot] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [appStatus, setAppStatus] = useState<AppStatus>('connected');
  
  // Data State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    tokensUsed: 1240,
    messagesCount: 0,
    agentUsage: {},
    history: [
      { date: 'Mon', count: 12 }, { date: 'Tue', count: 19 }, 
      { date: 'Wed', count: 3 }, { date: 'Thu', count: 5 }, 
      { date: 'Fri', count: 2 }, { date: 'Sat', count: 0 }, { date: 'Sun', count: 0 }
    ]
  });

  // Apply global body styles based on theme
  useEffect(() => {
    document.body.style.backgroundColor = themeMode === 'dark' 
      ? currentStyle.palette.background 
      : '#f8fafc'; // Default light bg
    
    // If specific light mode background is desired from palette
    if (themeMode === 'light') {
        document.body.style.backgroundColor = currentStyle.palette.background;
    }

    document.body.style.color = currentStyle.palette.text;
    document.body.style.fontFamily = currentStyle.fontPairing === 'Merriweather' 
      ? 'Merriweather, serif' 
      : 'Roboto, sans-serif';
  }, [currentStyle, themeMode]);

  const handleAddMessage = (msg: ChatMessage) => {
    setChatMessages(prev => [...prev, msg]);
    setAnalytics(prev => ({
      ...prev,
      messagesCount: prev.messagesCount + 1,
      // Update history for "Today" (simulated as the last entry)
      history: prev.history.map((h, i) => i === 6 ? { ...h, count: h.count + 1 } : h)
    }));
  };

  const handleIncrementUsage = () => {
    setAnalytics(prev => ({
      ...prev,
      tokensUsed: prev.tokensUsed + Math.floor(Math.random() * 50) + 10,
      agentUsage: {
        ...prev.agentUsage,
        [selectedAgent.name]: (prev.agentUsage[selectedAgent.name] || 0) + 1
      }
    }));
  };

  const handleUpdateAgent = (updatedAgent: Agent) => {
    setAgents(prev => prev.map(a => a.id === updatedAgent.id ? updatedAgent : a));
    if (selectedAgent.id === updatedAgent.id) {
      setSelectedAgent(updatedAgent);
    }
  };

  return (
    <div className={`flex h-screen w-full transition-colors duration-700 ease-in-out`}
         style={{ 
           backgroundColor: currentStyle.palette.background,
           color: currentStyle.palette.text
         }}>
      
      {/* Sidebar Container with Transition */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-0'} flex-shrink-0 h-full z-20 relative transition-all duration-300 ease-in-out overflow-hidden`}>
        <div className="w-64 h-full"> {/* Inner wrapper to fix width content while container shrinks */}
          <Sidebar 
            currentLang={language}
            setLang={setLanguage}
            currentTheme={themeMode}
            setTheme={setThemeMode}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            selectedAgent={selectedAgent}
            onSelectAgent={setSelectedAgent}
            agents={agents}
            currentStyle={currentStyle}
            onOpenJackpot={() => setShowJackpot(true)}
            onClose={() => setSidebarOpen(false)}
            appStatus={appStatus}
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Background Pattern/Texture if any */}
        <div className="absolute inset-0 opacity-5 pointer-events-none" 
             style={{ 
               backgroundImage: `radial-gradient(${currentStyle.palette.primary} 1px, transparent 1px)`,
               backgroundSize: '20px 20px'
             }}>
        </div>

        {/* Sidebar Open Button (visible only when closed) */}
        {!sidebarOpen && (
          <button 
            onClick={() => setSidebarOpen(true)}
            className="absolute top-4 left-4 z-50 p-2 rounded shadow-md transition-opacity hover:opacity-80"
            style={{ 
              backgroundColor: currentStyle.palette.primary, 
              color: '#ffffff' 
            }}
          >
            <Menu size={20} />
          </button>
        )}

        <main className="flex-1 relative z-10 p-4 overflow-hidden flex flex-col">
          {activeTab === 'chat' && (
            <div className="flex-1 overflow-hidden">
              <ChatInterface 
                currentLang={language}
                currentStyle={currentStyle}
                currentTheme={themeMode}
                selectedAgent={selectedAgent}
                messages={chatMessages}
                addMessage={handleAddMessage}
                incrementUsage={handleIncrementUsage}
                setAppStatus={setAppStatus}
              />
            </div>
          )}

          {activeTab === 'domain' && (
             <DomainAnalysis 
               currentLang={language}
               currentStyle={currentStyle}
               currentTheme={themeMode}
               incrementUsage={handleIncrementUsage}
               setAppStatus={setAppStatus}
             />
          )}

          {activeTab === 'agents' && (
             <AgentManager 
                agents={agents}
                setAgents={setAgents}
                currentStyle={currentStyle}
                currentLang={language}
                currentTheme={themeMode}
                onUpdateAgent={handleUpdateAgent}
             />
          )}

          {activeTab === 'analytics' && (
            <Analytics 
              data={analytics}
              currentStyle={currentStyle}
              currentLang={language}
              currentTheme={themeMode}
            />
          )}
        </main>
      </div>

      {/* Modals */}
      <JackpotStyleSelector 
        isOpen={showJackpot}
        onClose={() => setShowJackpot(false)}
        onSelectStyle={setCurrentStyle}
        currentLang={language}
      />
    </div>
  );
};

export default App;
