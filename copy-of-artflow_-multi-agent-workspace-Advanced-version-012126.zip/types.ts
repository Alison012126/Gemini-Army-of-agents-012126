export type Language = 'EN' | 'TC';
export type ThemeMode = 'light' | 'dark';
export type AppStatus = 'idle' | 'thinking' | 'error' | 'connected';

export interface PainterStyle {
  id: string;
  name: string;
  palette: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
    panel: string;
  };
  fontPairing: string;
  description: string;
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  category: string;
  description: string;
  model: string;
  systemInstruction?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model' | 'system';
  text: string;
  timestamp: number;
  agentId?: string;
}

export interface AnalyticsData {
  tokensUsed: number;
  messagesCount: number;
  agentUsage: Record<string, number>;
  history: { date: string; count: number }[];
}

export interface RegulatoryChecklistItem {
  id: string;
  text: string;
  checked: boolean;
  category: string;
}

export interface AttachedDocument {
  id: string;
  title: string;
  content: string;
  type: 'text' | 'markdown';
}
